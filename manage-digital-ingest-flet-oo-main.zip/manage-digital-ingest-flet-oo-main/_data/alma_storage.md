Azure storage is NOT used when `current_mode == Alma` because digital objects and their derivatives are stored in special `AWS S3` (that's `Amazon Web Services - Simple Storage Solution`) buckets as part of our `Alma` subscription.  

**Bottom line... there's nothing to do _in this page_.**

Once all pre-requisite processing is done, use the `Show Final Instructions` page to display (with copy/paste capability) the detailed instructions and `AWS S3` commands you'll need to run when completing the `Alma` ingest or bulk-import process.  

