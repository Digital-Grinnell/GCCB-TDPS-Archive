Click the '+' button to open the file picker dialog and select multiple images and/or PDF files.  

The selected file paths will be stored in `page.session['selected_object_paths']` for later processing.  
            
**Note:** In macOS, this app must be run as a browser app to use the file picker due to OS security restrictions.  
